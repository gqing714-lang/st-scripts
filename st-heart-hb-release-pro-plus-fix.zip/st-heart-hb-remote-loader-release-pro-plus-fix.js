/* 头像心声框：正式增强版二版修正版远程加载器
   上传 st-heart-hb-release-pro-plus-fix.js 到 GitHub 仓库根目录后使用。
   静默加载版：不弹诊断提示。
*/

(() => {
  const REMOTE_SCRIPT_URL =
    'https://cdn.jsdelivr.net/gh/gqing714-lang/st-scripts@main/st-heart-hb-release-pro-plus-fix.js?v=1&t=' + Date.now();

  const LOADER_FLAG = '__ST_HEART_HB_REMOTE_LOADER_RELEASE_PRO_PLUS_FIX__';

  if (window[LOADER_FLAG]) return;
  window[LOADER_FLAG] = true;

  const oldScript = document.querySelector('script[data-st-heart-hb-remote="1"]');
  if (oldScript) oldScript.remove();

  const script = document.createElement('script');
  script.src = REMOTE_SCRIPT_URL;
  script.async = true;
  script.dataset.stHeartHbRemote = '1';

  script.onload = () => {
    console.log('[头像心声框] 正式增强版二版修正版加载成功：', REMOTE_SCRIPT_URL);
  };

  script.onerror = () => {
    console.error('[头像心声框] 正式增强版二版修正版加载失败：', REMOTE_SCRIPT_URL);
  };

  (document.head || document.documentElement || document.body).appendChild(script);
})();
